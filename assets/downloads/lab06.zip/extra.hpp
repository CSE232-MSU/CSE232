/* 
 * File:   extra.h
 * Author: bill
 *
 * Created on October 10, 2013, 2:14 PM
 */
#ifndef SOME_VARIABLE_NAME
#define	SOME_VARIABLE_NAME
#include<string>
using std::string;
#include<vector>
using std::vector;

string my_fun(const vector<string>&);

#endif	/* EXTRA_H */

