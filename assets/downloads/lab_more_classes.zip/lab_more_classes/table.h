#pragma once

#include <iostream>
#include <vector>

class Table {
 private:
  std::vector<std::vector<int>> t_;  // 2D vector of long
  int width_;                        // how wide is t_ (how many columns)
  int height_;                       // how high is t_ (how many rows)
 public:
  // table will be width x height, default val is 0
  Table(int width, int height, int val = 0);
  void PrintTable(std::ostream&) const;
  // range from low to high, seed has default of 0
  void FillRandom(int low, int high, int seed = 0);
  bool SetValue(int x, int y, int val);
  int GetValue(int x, int y) const;
};
