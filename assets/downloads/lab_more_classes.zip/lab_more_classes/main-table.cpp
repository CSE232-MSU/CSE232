#include <iostream>
using std::boolalpha;
using std::cout;
using std::endl;
#include <exception>
using std::exception;
#include "table.h"

int main() {
  cout << boolalpha;

  Table my_table(5, 5);
  my_table.PrintTable(cout);
  cout << endl;

  my_table.FillRandom(1, 10);
  my_table.PrintTable(cout);
  cout << endl;

  bool result_bool = my_table.SetValue(100, 100, 100);
  cout << "Result:" << result_bool << endl;
  cout << endl;

  int result_int = my_table.GetValue(3, 2);
  cout << result_int << endl;
  try {
    result_int = my_table.GetValue(100, 100);
  } catch (std::out_of_range& e) {
    cout << "Correct!" << endl;
  }
  cout << endl;

  for (int i = 0; i < 5; i++) {
    my_table.SetValue(i, i + 1, i * i);
  }

  my_table.PrintTable(cout);
  cout << endl;
}
