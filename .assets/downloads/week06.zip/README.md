# Week 06

[Download this folder's content (*.zip file)](https://github.com/braedynl/CSE232/raw/master/.assets/downloads/week06.zip)

**Lectures**: 
