# Week 04

[Download this folder's content (*.zip file)](https://github.com/braedynl/CSE232/raw/master/.assets/downloads/week04.zip)

**Lectures**: 
