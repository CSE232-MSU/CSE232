# Week 03

[Download this folder's content (*.zip file)](https://github.com/braedynl/CSE232/raw/master/.assets/downloads/week03.zip)

**Lectures**: 
