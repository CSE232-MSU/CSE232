# Week 01

[Download this folder's content (*.zip file)](https://github.com/braedynl/CSE232/raw/master/.assets/downloads/week01.zip)

**Lectures**: 
