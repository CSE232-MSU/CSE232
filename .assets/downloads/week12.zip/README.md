# Week 12

[Download this folder's content (*.zip file)](https://github.com/braedynl/CSE232/raw/master/.assets/downloads/week12.zip)

**Lectures**: 
