#include "09.2-functions.h"


long f1(long p1, long p2){
  return p1 * p2;
}
