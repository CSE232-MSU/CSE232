#ifndef ROOTS_SOLVER
#define ROOTS_SOLVER

bool get_coefficients( double &, double &, double & );
int roots( double, double, double, double &, double & );

#endif

