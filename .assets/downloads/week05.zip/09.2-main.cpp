#include<iostream>
using std::cout; using std::endl;

#include "09.2-functions.h"

int main(){
  cout << f1(10,20) << endl;
  cout << f1(20) << endl;
}
