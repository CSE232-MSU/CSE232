# Week 02

[Download this folder's content (*.zip file)](https://github.com/braedynl/CSE232/raw/master/.assets/downloads/week02.zip)

**Lectures**: 
